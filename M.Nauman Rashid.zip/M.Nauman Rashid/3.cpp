//# include <iostream>
//using namespace std;
//void count(char *a);
//int main()
//{
//	char arr[100] = {};
//	char *a = arr;
//	cout << "Enter text : ";
//	cin.getline(arr, 100);
//	count(a);
//	system("pause");
//}
//void count(char *a)
//{
//	int j = 0;
//	for (int i=0; a[i] != '\0'; i++)
//	{
//		if (a[i] == ' ')
//		{
//			j++;
//		}
//	}
//	cout << "Total number of words are : " << ++j << endl;
//}