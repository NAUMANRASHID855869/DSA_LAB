//#include<iostream>
//using namespace std;
//void swap(int * a, int *b);
//int main()
//{
//	int a, b;
//	int* c = &a;
//	int* d = &b;
//	cout << "Enter two numbers : ";
//	cin >> *c;
//	cin >> *d;
//	cout << "After swap : ";
//	swap(c, d);
//	cout << *c << " " << *d << endl;
//	system("pause");
//}
//void swap(int * a, int *b)
//{
//	int temp = *a;
//	*a = *b;
//	*b = temp;
//}