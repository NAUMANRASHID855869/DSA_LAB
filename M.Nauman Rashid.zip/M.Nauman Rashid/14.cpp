//# include <iostream>
//using namespace std;
//void special(char *a);
//int main()
//{
//	char arr[100] = {};
//	char *a = arr;
//	cout << "Enter text : ";
//	cin.getline(arr, 100);
//	cout << "after removing special characters in text : ";
//	special(a);
//}
//void special(char *a)
//{
//	for (int i = 0; a[i] != '\0'; i++)
//	{
//		if ((a[i] >= 'A' && a[i] <= 'Z') || (a[i] >= 'a' && a[i] <= 'z'))
//		{
//			cout << a[i];
//		}
//	}
//	cout <<  endl;
//}