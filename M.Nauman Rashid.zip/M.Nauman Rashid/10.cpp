//# include <iostream>
//using namespace std;
//void area(int *a , int *b);
//int main()
//{
//	int r = 0;
//	int *a = &r;
//	int d = 0;
//	int *b = &d;
//	cout << "Enter length of rectangle : ";
//	cin >> *a;
//	cout << "Enter width of rectangle : ";
//	cin >> *b;
//	area(a,b);
//}
//void area(int *a,int *b)
//{
//	cout << "area of rectangle is equal to : " << (*a)*(*b) << endl;
//}